package waypoint;

public interface EventWaypoint {

    public void selected(MyWaypoint waypoint);
}